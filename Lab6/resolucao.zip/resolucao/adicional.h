void print_octal(int num);
