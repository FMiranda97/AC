void print_octal(int num){
	printf("%o\n", num);
} 

