int vfor(int a, int b);
int vwhile(int a, int b);
int vdo(int a, int b);

